#ifndef RUNTIME_CONFIG_STORE_H
#define RUNTIME_CONFIG_STORE_H

#include <stdint.h>

struct RuntimeConfigSnapshot {
    bool autoReconnectEnabled;
    uint32_t fastReconnectTtlMs;
    uint8_t ledMask;
    uint8_t reportingMode;
    bool reportingContinuous;
    // Last connected Wiimote (PATCH: persisted so fast reconnect survives
    // reboots — the stock library kept this in RAM only, so every reboot
    // wiped the cache and a Power-on could never reconnect until the user
    // pressed 1+2 to re-pair). The clock offset is NOT stored: fast
    // reconnect pages without it (see startFastReconnect).
    uint8_t lastWiimoteAddr[6];
    uint8_t lastWiimotePsrm;
    bool hasLastWiimote;
    bool lastWiimoteIsClone;
};

class RuntimeConfigStore {
   public:
    RuntimeConfigStore();

    bool init();
    bool save(const RuntimeConfigSnapshot &snapshot) const;
    bool load(RuntimeConfigSnapshot *snapshot) const;
    bool clear() const;

   private:
    bool initialized_;
};

#endif  // RUNTIME_CONFIG_STORE_H
