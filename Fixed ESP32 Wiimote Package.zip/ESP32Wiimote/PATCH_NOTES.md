# ESP32Wiimote 2.0.2 — patched (reconnect fix)

Base: andremmfaria/ESP32Wiimote 2.0.0 (stock, as uploaded by the user).
Version bumped to 2.0.2 so the Arduino IDE does not confuse it with stock.

## What was wrong

1. **The reconnect cache was RAM-only.** Every reboot (power cycle, crash,
   re-upload) wiped the cached remote address, so the ESP32 had nothing to
   page. A Power-on remote is NOT discoverable (it only listens for a page
   from a known host), so the ESP32's inquiry never found it either. The
   user had to press 1+2 to re-pair after every reboot.
2. **The cache timestamp was set at connect and never updated.** The TTL
   was measured from the original connection, so a session longer than
   the TTL expired the cache WHILE STILL CONNECTED. Turning the remote
   off and back on after a long session never reconnected — same
   page-scan-only problem as (1), but without any reboot.
3. **The reconnect cycle spent most of its time scanning, not paging.**
   Stock: page (~5 s, fails) -> inquiry (6.4 s) -> reset (~1 s) -> repeat.
   The ESP32 only paged ~28% of the time, so a Power-on could wait ~13 s
   for the next page window.

## The fix (4 changes)

1. **NVS persistence for the last Wiimote address** (`config/`,
   `TinyWiimote.*`, `ESP32Wiimote.*`). On every new connection, the
   remote's address + page-scan mode + clone flag are saved to NVS
   (namespace `wm_cfg`, keys `last_addr`/`last_psrm`/`has_last`/
   `last_clone`). On boot, `init()` restores the cache, so fast
   reconnect works immediately after a reboot. The TTL counts from boot
   (24 h with the bridge sketch). The new NVS keys are optional on read,
   so an NVS written by the stock library still loads fine.
2. **Timestamp refresh on disconnect** (`tinywiimote/hci/hci_events.cpp`).
   `lastWiimoteSeenMs` is now updated in `handleDisconnectionComplete`,
   so the TTL counts from when the remote was last present (the
   disconnect), not from the original connection. A long session no
   longer expires the cache.
3. **Shorter auto-inquiry** (`tinywiimote/hci/hci_events.cpp`):
   6.4 s -> 2.56 s. A discoverable Wiimote answers within ~1 s, so the
   long inquiry only wasted paging time. Cycle is now ~8.6 s (58%
   paging); worst-case Power-on wait is ~3 s. The inquiry fallback is
   KEPT: if the cached address is wrong, the inquiry still finds ANY
   Wiimote in range and the cache is replaced on connect.
4. **Version 2.0.0 -> 2.0.2** (`library.properties`).

## Install

1. In Arduino IDE: delete the stock ESP32Wiimote library
   (Sketch > Include Library > Manage Libraries, or delete the
   ESP32Wiimote folder from your libraries folder).
2. Sketch > Include Library > Add .ZIP Library > this file.
3. Never update it from Library Manager (that would reinstall stock).

First connection after installing: press 1+2 (or SYNC) once to pair.
After that, a plain Power press reconnects — even after rebooting the
ESP32 or after a long session — because the address is now in NVS and
the TTL counts from the last disconnect.
