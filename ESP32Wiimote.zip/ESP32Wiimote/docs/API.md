# ESP32Wiimote API Reference

Complete API documentation for the ESP32Wiimote library.

## Table of Contents

- [ESP32Wiimote Class](#esp32wiimote-class)
- [Runtime Wi-Fi/Auth Configuration](#runtime-wi-fiauth-configuration)
- [Serial Control Interface](#serial-control-interface)
- [Wi-Fi Control API](#wi-fi-control-api)
- [Button States](#button-states)
- [Sensor Data Structures](#sensor-data-structures)
- [Filter Configuration](#filter-configuration)

---

## ESP32Wiimote Class

### Constructor

```cpp
ESP32Wiimote()
ESP32Wiimote(const ESP32WiimoteConfig &config)
```

Creates a new ESP32Wiimote instance.

Use the default constructor when you do not need to override any settings.

```cpp
ESP32Wiimote wiimote;
```

### Configuration Object

```cpp
struct ESP32WiimoteConfig {
    int nunchukStickThreshold = 1;
    int txQueueSize = 32;
    int rxQueueSize = 32;
    uint32_t fastReconnectTtlMs = 180000;
};
```

Use the config object when you want to override defaults.

```cpp
ESP32WiimoteConfig cfg;
cfg.nunchukStickThreshold = 5;
cfg.fastReconnectTtlMs = 180000;  // 3 minutes

ESP32Wiimote wiimote(cfg);
```

Set `fastReconnectTtlMs = 0` to disable fast reconnect and always use inquiry after disconnect.

---

### Runtime Wi-Fi/Auth Configuration

Runtime tokens and Wi-Fi policy are configured via `ESP32WiimoteConfig`:

```cpp
struct WiimoteNetworkCredentials {
    const char *ssid;
    const char *password;
};

struct ESP32WiimoteAuthConfig {
    const char *serialPrivilegedToken;
    const char *wifiApiToken;
    bool wifiTokenFallbackToSerial;
};

struct ESP32WiimoteWifiConfig {
    bool enabled;
    WifiDeliveryMode deliveryMode;
    WiimoteNetworkCredentials network;
};

struct ESP32WiimoteConfig {
    int nunchukStickThreshold;
    int txQueueSize;
    int rxQueueSize;
    uint32_t fastReconnectTtlMs;
    ESP32WiimoteAuthConfig auth;
    ESP32WiimoteWifiConfig wifi;
};
```

Prefer constructing the device with this configuration before `init()`:

```cpp
ESP32WiimoteConfig runtimeConfig;
runtimeConfig.auth.serialPrivilegedToken = "esp32wiimote_serial_token_v1";
runtimeConfig.auth.wifiApiToken = "esp32wiimote_wifi_api_token_v1";
runtimeConfig.wifi.enabled = true;
runtimeConfig.wifi.deliveryMode = WifiDeliveryMode::RestOnly;
runtimeConfig.wifi.network = {"YOUR_WIFI_SSID", "YOUR_WIFI_PASSWORD"};

ESP32Wiimote wiimote(runtimeConfig);
wiimote.enableWifiControl(true, WifiDeliveryMode::RestOnly);
```

#### `void configure(const ESP32WiimoteConfig &config)`

Sets runtime tokens and Wi-Fi enablement policy.

Behavior:

- `config.wifi.enabled=false` prevents Wi-Fi control startup
- `config.auth.serialPrivilegedToken` is used for serial unlock validation (`wm unlock <token> [seconds]`)
- `config.auth.wifiApiToken` is used for Wi-Fi Bearer auth
- if `config.auth.wifiApiToken` is null/empty and `config.auth.wifiTokenFallbackToSerial=true`, Wi-Fi auth falls back to `config.auth.serialPrivilegedToken` and startup prints `@wm: info wifi_api_token_missing_using_serial_token`
- when Wi-Fi control is enabled, valid runtime network credentials are required for station join
- serial control remains available regardless of `config.wifi.enabled`
- partial updates are supported for auth/Wi-Fi fields: omitted fields preserve current values

#### `const ESP32WiimoteConfig &getConfig() const`

Returns the active public configuration snapshot held by the instance.

Use this to read the currently applied runtime auth/Wi-Fi policy after construction or after one or more `configure(...)` calls.

```cpp
const ESP32WiimoteConfig &cfg = wiimote.getConfig();
if (cfg.wifi.enabled) {
    wiimote.enableWifiControl(true, cfg.wifi.deliveryMode);
}
```

#### `void enableWifiControl(bool enabled, WifiDeliveryMode deliveryMode = WifiDeliveryMode::RestOnly)`

Enables or disables Wi-Fi control lifecycle. Startup is asynchronous and progresses in `task()`.

#### `bool updateWifiNetworkCredentials(const char *ssid, const char *password)`

Updates runtime SSID/password. Returns `false` when either value is null/empty.

#### `bool restartWifiControl()`

Restarts Wi-Fi lifecycle using the current runtime config. Returns `false` when Wi-Fi control is disabled.

#### `bool updateWifiApiToken(const char *token)`

Updates runtime Wi-Fi API Bearer token. Returns `false` when token is null/empty.

#### `bool setWifiDeliveryMode(WifiDeliveryMode deliveryMode)`

Updates runtime delivery mode (`RestOnly` or `RestAndWebSocket`). When Wi-Fi control is enabled, lifecycle stages restart.

#### `bool isWifiControlEnabled() const`

Returns whether Wi-Fi lifecycle processing is enabled.

#### `bool isWifiControlReady() const`

Returns whether Wi-Fi startup stages have completed.

#### `bool hasWifiApiToken() const`

Returns `true` when a Wi-Fi API token is currently configured.

#### `WifiControlState getWifiControlState() const`

Returns lifecycle state flags (`enabled`, `initializing`, `ready`, stage registration flags, and delivery mode).

---

### Initialization & Task Management

#### `bool init()`

Initializes Bluetooth controller and HCI interface. Must be called once in `setup()`.

**Returns:** `true` on success, `false` if Bluetooth initialization fails

**Example:**

```cpp
void setup() {
    Serial.begin(115200);
    wiimote.init();
}
```

**Notes:**

- Initializes Bluetooth in non-discoverable mode
- Starts HCI packet queues
- Registers VHCI callbacks
- Supports one active Wiimote connection per ESP32 radio due to Bluetooth Classic HCI limitations
- Must be called before any other methods

---

#### `void task()`

Processes HCI packet queues. Must be called regularly in `loop()`.

**Example:**

```cpp
void loop() {
    wiimote.task();
    // ... your code ...
}
```

**Notes:**

- Handles incoming/outgoing Bluetooth packets
- Should be called as frequently as possible
- Non-blocking operation
- When serial control is enabled, processes at most one complete serial command line per call

---

### Connection Status

#### `bool isConnected()`

Checks if Wiimote is currently connected.

**Returns:** `true` if connected, `false` otherwise

**Connection model:**

- Single-controller design: one active Wiimote per ESP32 radio due to Bluetooth Classic HCI limitations

**Reconnect behavior:**

- After an unexpected disconnect, the stack attempts a fast reconnect to the last connected controller for up to 3 minutes
- If fast reconnect fails, it falls back to normal inquiry and can connect to another compatible controller
- When a different controller is found and connected, the previous fast-reconnect cache is cleared and replaced immediately

**Example:**

```cpp
if (wiimote.isConnected()) {
    Serial.println("Wiimote ready");
}
```

---

### Data Availability

#### `int available()`

Checks if new sensor or button data is available.

**Returns:**

- `1` if data has changed since last check
- `0` if no new data

**Example:**

```cpp
void loop() {
    wiimote.task();
    
    if (wiimote.available()) {
        // Process new data
        ButtonState btn = wiimote.getButtonState();
    }
}
```

**Notes:**

- Automatically parses incoming HCI reports
- Resets change flags after reading
- Filters are applied before returning

---

### Button Input

#### `ButtonState getButtonState()`

Gets current button state.

**Returns:** `ButtonState` enum value (see [Button States](#button-states))

**Example:**

```cpp
ButtonState btn = wiimote.getButtonState();

if (btn == BUTTON_A) {
    Serial.println("A button pressed");
}

// Check combinations
if (btn & BUTTON_A) {
    Serial.println("A is pressed (maybe with others)");
}
```

---

### Sensor Data

#### `AccelState getAccelState()`

Gets current Wiimote accelerometer state.

**Returns:** `AccelState` struct with x, y, z values (0-255)

**Example:**

```cpp
AccelState accel = wiimote.getAccelState();

Serial.printf("Accel: X=%d Y=%d Z=%d\n", 
    accel.xAxis, accel.yAxis, accel.zAxis);
```

**Notes:**

- Values are raw 8-bit accelerometer readings
- Typical rest position: ~128 for each axis
- Requires accelerometer mode enabled (see demo)

---

#### `NunchukState getNunchukState()`

Gets current Nunchuk state (if connected).

**Returns:** `NunchukState` struct with stick position, accelerometer, and buttons

**Example:**

```cpp
NunchukState nunchuk = wiimote.getNunchukState();

Serial.printf("Stick: X=%d Y=%d\n", 
    nunchuk.xStick, nunchuk.yStick);
Serial.printf("Accel: X=%d Y=%d Z=%d\n",
    nunchuk.xAccel, nunchuk.yAccel, nunchuk.zAccel);

if (nunchuk.cBtn) Serial.println("C button");
if (nunchuk.zBtn) Serial.println("Z button");
```

**Notes:**

- Returns default values if Nunchuk not connected
- Stick: 0-255 (center ~128)
- Accelerometer: 0-255 (rest ~128)

---

### Battery Management

#### `uint8_t getBatteryLevel()`

Gets battery level percentage.

**Returns:** Battery level in range 0-100 (percentage)

**Example:**

```cpp
uint8_t battery = wiimote.getBatteryLevel();
Serial.printf("Battery: %d%%\n", battery);
```

**Notes:**

- Returns 0-100 (percentage, not raw value)
- Updated automatically when Wiimote connects
- Call `requestBatteryUpdate()` for manual refresh

---

#### `void requestBatteryUpdate()`

Requests a battery status update from the Wiimote.

**Example:**

```cpp
// Refresh battery level every 60 seconds
static unsigned long lastUpdate = 0;
if (millis() - lastUpdate > 60000) {
    wiimote.requestBatteryUpdate();
    lastUpdate = millis();
}
```

**Notes:**

- Asynchronous - battery value updates when response is received
- Only works when connected
- Battery is automatically requested on initial connection

---

### Output Control

#### `bool setLeds(uint8_t ledMask)`

Sets the Wiimote LED bitmask.

**Parameters:**

- `ledMask` - LED bitmask (bit 0..3 map to LEDs 1..4)

**Returns:** `true` if command was queued, `false` if not connected

**Preconditions / guards:**

- Requires an active Wiimote connection
- Returns `false` when no connection is available

#### `bool setReportingMode(ReportingMode mode, bool continuous = false)`

Sets Wiimote input reporting mode.

**Parameters:**

- `mode` - reporting mode enum value
- `continuous` - `true` for continuous reports, `false` for change-based reports

**Returns:** `true` if command was queued, `false` if not connected

**Preconditions / guards:**

- Requires an active Wiimote connection
- Returns `false` when no connection is available

#### `bool setAccelerometerEnabled(bool enabled)`

Enables or disables accelerometer usage in runtime parsing.

**Parameters:**

- `enabled` - `true` to enable accelerometer handling, `false` to disable

**Returns:** Always `true`

**Preconditions / guards:**

- No connection required
- This controls local runtime behavior and affects subsequent report handling

#### `bool requestStatus()`

Requests a status report from the currently connected controller.

**Returns:** `true` if command was queued, `false` if not connected

**Preconditions / guards:**

- Requires an active Wiimote connection
- Returns `false` when no connection is available

#### `bool writeMemory(uint8_t addressSpace, uint32_t offset, const uint8_t *data, uint8_t len)`

Writes data to Wiimote EEPROM or control-register address space.

**Parameters:**

- `addressSpace` - `WiimoteAddressSpace` value cast to `uint8_t`
- `offset` - address offset inside selected space
- `data` - pointer to payload bytes
- `len` - payload length

**Returns:** `true` if command was queued, `false` if not connected

**Preconditions / guards:**

- Requires an active Wiimote connection
- Returns `false` when no connection is available

#### `bool readMemory(uint8_t addressSpace, uint32_t offset, uint16_t size)`

Reads data from Wiimote EEPROM or control-register address space.

**Parameters:**

- `addressSpace` - `WiimoteAddressSpace` value cast to `uint8_t`
- `offset` - address offset inside selected space
- `size` - number of bytes to read

**Returns:** `true` if command was queued, `false` if not connected

**Preconditions / guards:**

- Requires an active Wiimote connection
- Returns `false` when no connection is available

---

### Bluetooth Controller Runtime Control

Controller runtime methods are guarded by a deterministic transition model documented in
`docs/ARCHITECTURE.md` under "Controller Command State Machine".

#### `void setScanEnabled(bool enabled)`

Enables or disables Bluetooth scan mode at runtime.

**Parameters:**

- `enabled` - `true` to enable scan mode, `false` to disable

**Preconditions / guards:**

- Controller runtime must be initialized (`init()` + runtime startup complete)
- When disconnected, redundant transitions are rejected internally (no command sent)

**Lifecycle behavior:**

- `scanning` is updated immediately from submitted scan commands
- `scanning` is forced to `false` when the first active controller connection is established

#### `bool startDiscovery()`

Starts inquiry/discovery flow.

**Returns:** `true` when start request is accepted, `false` when rejected by guards

**Preconditions / guards:**

- Controller runtime must be initialized (`init()` + runtime startup complete)
- Discovery is rejected if scanning is already active
- Discovery is rejected while already connected

#### `bool stopDiscovery()`

Stops inquiry/discovery flow.

**Returns:** `true` when stop request is accepted, `false` when rejected by guards

**Preconditions / guards:**

- Controller runtime must be initialized (`init()` + runtime startup complete)
- Stop request is rejected if scanning is not active
- Stop request is rejected while connected

#### `bool disconnectActiveController(DisconnectReason reason)`

Requests disconnect of the active controller.

**Parameters:**

- `reason` - HCI disconnect reason enum value

**Returns:** `true` when disconnect command is sent, `false` if no active connection

**Preconditions / guards:**

- Controller runtime must be initialized (`init()` + runtime startup complete)
- Requires an active Wiimote connection and valid connection handle

#### `void setAutoReconnectEnabled(bool enabled)`

Enables or disables auto-reconnect policy.

**Parameters:**

- `enabled` - `true` to enable policy, `false` to disable

**Preconditions / guards:**

- Controller runtime must be initialized (`init()` + runtime startup complete)
- If runtime is not initialized, the request is ignored

#### `void clearReconnectCache()`

Clears cached controller identity used by fast reconnect.

**Preconditions / guards:**

- Controller runtime must be initialized (`init()` + runtime startup complete)
- If runtime is not initialized, the request is ignored

#### `BluetoothControllerState getBluetoothControllerState()`

Returns a snapshot of Bluetooth controller runtime state.

**Returns:** `BluetoothControllerState` with initialization, start, scan, connection, and reconnect flags

---

### Serial Control Interface

#### `void enableSerialControl(bool enabled)`

Enables or disables serial command processing inside `task()`.

**Behavior:**

- Disabled by default
- When disabled, queued partial serial input is cleared
- Disabling also clears the active serial unlock session

#### `bool isSerialControlEnabled() const`

Returns whether serial command processing is enabled.

#### Protocol overview

- Prefix: `wm`
- One command per line (`\n`-terminated)
- Response prefix: `@wm:`
- Maximum input line length: 128 bytes (excluding `\0` terminator)
- Maximum token count: 10

#### Implemented command set

- `wm status`
- `wm unlock <token> [seconds]`
- `wm led <mask>`
- `wm mode <mode> [continuous]`
- `wm accel <on|off>`
- `wm request-status`
- `wm scan <on|off>`
- `wm discover <start|stop>`
- `wm disconnect [reason]`
- `wm reconnect <on|off|clear>`
- `wm wifi-status`
- `wm wifi-control <on|off>`
- `wm wifi-mode <rest|rest-ws>`
- `wm wifi-set-network <ssid> <password>`
- `wm wifi-restart`
- `wm wifi-set-token <token>`

#### Response contract

Success:

- `@wm: ok`
- `@wm: ok queued` (reserved for queued flows)

Error examples:

- `@wm: error unknown_command`
- `@wm: error bad_argument`
- `@wm: error missing_argument`
- `@wm: error not_connected`
- `@wm: error locked`
- `@wm: error bad_credentials`
- `@wm: error line_too_long`
- `@wm: error policy_blocked`

#### Privileged-command lock model

Serial privileged commands are locked by default.

- `wm unlock <token> [seconds]` starts a token-validated, time-bounded unlock session
- default unlock duration is 60 seconds when `[seconds]` is omitted
- invalid token returns `@wm: error bad_credentials`
- while unlocked, privileged commands are accepted (subject to normal state guards)
- after expiry, privileged commands return `@wm: error locked`

Privileged command set includes write/control operations such as `led`, `mode`, `accel`, `scan`, `discover`, `disconnect`, and `reconnect`.
It also includes Wi-Fi mutation commands: `wifi-control`, `wifi-mode`, `wifi-set-network`, `wifi-restart`, and `wifi-set-token`.

#### Controller Guard Semantics

Runtime controller operations are validated before HCI command submission. Invalid
transitions are rejected deterministically.

Scanning-state lifecycle is command-driven: accepted scan-enable commands set
`scanning=true`, accepted scan-disable commands set `scanning=false`, and
connection establishment forces `scanning=false`.

| From state                           | Allowed commands                                                                                                           |
| ------------------------------------ | -------------------------------------------------------------------------------------------------------------------------- |
| Not started                          | none (all rejected)                                                                                                        |
| Started, not connected, not scanning | `setScanEnabled(true)`, `startDiscovery`, reconnect-policy/cache operations                                                |
| Started, scanning                    | `stopDiscovery`, `setScanEnabled(false)`, reconnect-policy/cache operations                                                |
| Started, connecting                  | none (intermediate state; transitions complete from HCI events)                                                            |
| Connected                            | `requestStatus`, `setLeds`, `setReportingMode`, `setAccelerometerEnabled`, `disconnect`, reconnect-policy/cache operations |
| Connected                            | `setScanEnabled(...)` is allowed but does not affect the active connection                                                 |

Deterministic rejection examples:

- `startDiscovery()` while already scanning/discovering -> rejected
- `stopDiscovery()` while discovery is idle -> rejected
- `disconnectActiveController(...)` while disconnected -> rejected
- Any controller operation before runtime initialization -> rejected/no-op (by method contract)

---

### Wi-Fi Control API

Wi-Fi control is exposed as an authenticated REST API with a static OpenAPI document.

#### Auth model

- API routes require `Authorization: Bearer <token>`
- missing or invalid token returns HTTP `401`

#### Static routes

- `GET /` -> control page (`text/html`)
- `GET /app.js` -> browser client script (`application/javascript`)
- `GET /styles.css` -> stylesheet (`text/css`)
- `GET /openapi.json` -> OpenAPI 3.0 contract (`application/json`)

#### REST read endpoints

- `GET /api/wiimote/status`
- `GET /api/wiimote/config`
- `GET /api/wifi/control`
- `GET /api/commands/<id>/status`

#### Optional WebSocket event endpoints

Available only when `enableWifiControl(..., WifiDeliveryMode::RestAndWebSocket)` is used:

- `GET /api/wiimote/input/events`
- `GET /api/wiimote/status/events`

Event frame envelope:

```json
{
    "seq": 42,
    "event": "input",
    "payload": { ... }
}
```

Recovery contract:

- each channel (`input` and `status`) uses its own monotonically increasing `seq`
- events are retained in bounded per-channel buffers and oldest frames are dropped under backpressure
- if reconnect replay detects a sequence gap, clients should fetch REST snapshots and resume from `nextSeq`

#### REST write endpoints

- `POST /api/wiimote/commands/leds`
- `POST /api/wiimote/commands/reporting-mode`
- `POST /api/wiimote/commands/accelerometer`
- `POST /api/wiimote/commands/request-status`
- `POST /api/wiimote/commands/scan`
- `POST /api/wiimote/commands/discovery`
- `POST /api/wiimote/commands/disconnect`
- `POST /api/wiimote/commands/reconnect-policy`
- `POST /api/wifi/control`
- `POST /api/wifi/delivery-mode`
- `POST /api/wifi/network`
- `POST /api/wifi/restart`
- `POST /api/wifi/token` (policy-gated)

#### HTTP result mapping

- `200` command/read accepted
- `400` malformed or missing request body fields
- `401` auth failed
- `403` policy-blocked mutations (for example, Wi-Fi API token updates when policy is disabled)
- `409` command rejected by runtime guards

---

### Public Types

#### `enum class ReportingMode : uint8_t`

Supported reporting modes exposed by the public API:

- `CoreButtons` (`0x30`)
- `CoreButtonsAccel` (`0x31`)
- `CoreButtonsAccelIr` (`0x33`)
- `CoreButtonsAccelExt` (`0x35`)

#### `enum class DisconnectReason : uint8_t`

Supported disconnect reason codes:

- `LocalHostTerminated` (`0x16`)
- `RemoteUserTerminated` (`0x13`)
- `AuthenticationFailure` (`0x05`)
- `PowerOff` (`0x15`)

#### `struct BluetoothControllerState`

Runtime controller-state snapshot fields:

- `initialized`
- `started`
- `scanning`
- `connected`
- `activeConnectionHandle`
- `fastReconnectActive`
- `autoReconnectEnabled`

#### `enum class WifiDeliveryMode : uint8_t`

Wi-Fi route delivery mode:

- `RestOnly`
- `RestAndWebSocket`

#### `struct WifiControlState`

Wi-Fi lifecycle snapshot fields:

- `enabled`
- `initializing`
- `ready`
- `networkCredentialsConfigured`
- `networkConnectAttempted`
- `networkConnected`
- `networkConnectFailed`
- `deliveryMode`
- `wifiLayerStarted`
- `littleFsMounted`
- `staticRoutesRegistered`
- `apiRoutesRegistered`
- `websocketRoutesRegistered`

---

### Filtering

#### `void addFilter(FilterAction action, int filter)`

Configures data filters to reduce update frequency.

**Parameters:**

- `action` - Filter action (currently only `FilterAction::Ignore`)
- `filter` - Data type to filter (`kFilterButton`, `kFilterAccel`, `kFilterNunchukStick`)

**Available Filters:**

- `kFilterButton` - Ignore button changes
- `kFilterAccel` - Ignore Wiimote accelerometer changes
- `kFilterNunchukStick` - Ignore Nunchuk stick changes

**Example:**

```cpp
void setup() {
    wiimote.init();
    
    // Only care about buttons, ignore motion
    wiimote.addFilter(FilterAction::Ignore, kFilterAccel);
    wiimote.addFilter(FilterAction::Ignore, kFilterNunchukStick);
}
```

**Notes:**

- Filters are applied in `available()`
- Can be combined (multiple filters active)
- Does not affect raw data reading

---

## Button States

```cpp
enum ButtonState {
    BUTTON_NONE           = 0x0000,
    
    // D-Pad
    BUTTON_LEFT           = 0x0001,
    BUTTON_RIGHT          = 0x0002,
    BUTTON_DOWN           = 0x0004,
    BUTTON_UP             = 0x0008,
    
    // Face buttons
    BUTTON_PLUS           = 0x0010,
    
    // System buttons
    BUTTON_TWO            = 0x0100,
    BUTTON_ONE            = 0x0200,
    BUTTON_B              = 0x0400,
    BUTTON_A              = 0x0800,
    BUTTON_MINUS          = 0x1000,
    BUTTON_HOME           = 0x8000,
    
    // Nunchuk
    BUTTON_Z              = 0x0001,  // Via Nunchuk
    BUTTON_C              = 0x0002,  // Via Nunchuk
};
```

### Checking Button States

**Single Button:**

```cpp
if (btn == BUTTON_A) {
    // Only A pressed
}
```

**Button Combinations:**

```cpp
if ((btn & BUTTON_A) && (btn & BUTTON_B)) {
    // A and B pressed together
}
```

**Any of Multiple:**

```cpp
if (btn & (BUTTON_UP | BUTTON_DOWN | BUTTON_LEFT | BUTTON_RIGHT)) {
    // Any D-Pad pressed
}
```

---

## Sensor Data Structures

### AccelState

```cpp
struct AccelState {
    uint8_t xAxis;  // 0-255, ~128 at rest
    uint8_t yAxis;  // 0-255, ~128 at rest
    uint8_t zAxis;  // 0-255, ~128 at rest
};
```

### NunchukState

```cpp
struct NunchukState {
    uint8_t xStick;   // 0-255, ~128 centered
    uint8_t yStick;   // 0-255, ~128 centered
    uint8_t xAccel;   // 0-255, ~128 at rest
    uint8_t yAccel;   // 0-255, ~128 at rest
    uint8_t zAccel;   // 0-255, ~128 at rest
    bool cBtn;        // C button state
    bool zBtn;        // Z button state
};
```

---

## Filter Configuration

### FILTER_BUTTON

Ignores button state changes. `available()` returns 0 even when buttons change.

**Use case:** Reading only motion data

### FILTER_ACCEL

Ignores Wiimote accelerometer changes.

**Use case:** Buttons-only gameplay

### FILTER_NUNCHUK_STICK

Ignores Nunchuk analog stick position changes.

**Use case:** Using only Nunchuk buttons, not stick

---

## Complete Example

```cpp
#include "ESP32Wiimote.h"

ESP32Wiimote wiimote;

void setup() {
    Serial.begin(115200);
    wiimote.init();
}

void loop() {
    wiimote.task();
    
    // Check connection
    if (!wiimote.isConnected()) {
        delay(100);
        return;
    }
    
    // Process data when available
    if (wiimote.available()) {
        // Buttons
        ButtonState btn = wiimote.getButtonState();
        if (btn == BUTTON_A) {
            Serial.println("A pressed");
        }
        
        // Accelerometer
        AccelState accel = wiimote.getAccelState();
        Serial.printf("Accel: %d, %d, %d\n", 
            accel.xAxis, accel.yAxis, accel.zAxis);
        
        // Nunchuk
        NunchukState nunchuk = wiimote.getNunchukState();
        Serial.printf("Stick: %d, %d\n", 
            nunchuk.xStick, nunchuk.yStick);
    }
    
    // Battery check (every 60 seconds)
    static unsigned long lastBattery = 0;
    if (millis() - lastBattery > 60000) {
        uint8_t battery = wiimote.getBatteryLevel();
        Serial.printf("Battery: %d%%\n", battery);
        lastBattery = millis();
    }
}
```

---

## See Also

- [Testing Guide](TESTING.md) - Running unit tests
- [Logging System](LOGGING.md) - Debug output configuration
- [Architecture](ARCHITECTURE.md) - Internal system design
