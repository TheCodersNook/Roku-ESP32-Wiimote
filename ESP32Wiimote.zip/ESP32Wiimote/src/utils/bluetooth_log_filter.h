// Copyright (c) 2020 Daiki Yasuda
//
// This is licensed under
// - Creative Commons Attribution-NonCommercial 3.0 Unported
// - https://creativecommons.org/licenses/by-nc/3.0/
// - Or see LICENSE.md

#ifndef ESP32_WIIMOTE_BLUETOOTH_LOG_FILTER_H
#define ESP32_WIIMOTE_BLUETOOTH_LOG_FILTER_H

/**
 * Reduce noisy ESP-IDF / Bluedroid output without touching the library's own
 * Serial logging. Safe to call more than once.
 */
void wiimoteInstallBluetoothLogFilter();

#endif  // ESP32_WIIMOTE_BLUETOOTH_LOG_FILTER_H
