// Copyright (c) 2020 Daiki Yasuda
//
// This is licensed under
// - Creative Commons Attribution-NonCommercial 3.0 Unported
// - https://creativecommons.org/licenses/by-nc/3.0/
// - Or see LICENSE.md

#include "bluetooth_log_filter.h"

#if defined(ARDUINO_ARCH_ESP32) || defined(ESP_PLATFORM)

#include "esp32-hal-uart.h"
#include "esp_log.h"
#include "hal/uart_ll.h"
#include "rom/ets_sys.h"
#include "soc/soc_caps.h"
#include "soc/uart_struct.h"

#include <stddef.h>
#include <stdint.h>
#include <string.h>

namespace {

constexpr char kAssertWarnMarker[] = "ASSERT_WARN(";
constexpr char kAssertErrMarker[] = "ASSERT_ERR(";
constexpr size_t kMarkerLen = sizeof(kAssertWarnMarker);  // includes NUL
constexpr size_t kWindowSize = 96;
constexpr unsigned kMaxSuppressedChars = 256;

char gPending[kMarkerLen] = {};
size_t gPendingLen = 0;

char gWindow[kWindowSize + 1] = {};
bool gSuppressing = false;
unsigned gSuppressedChars = 0;
bool gInstalled = false;

const char *const kBtLogTags[] = {
    "BT",      "BT_LOG",  "BT_BTM",  "BT_L2CAP", "BT_HCI",   "BT_HIDH",
    "BT_HIDD", "BT_GAP",  "BT_RFCOMM", "BT_SDP",  "BT_BTIF",  "BT_APPL",
    "BT_AVDT", "BT_AVCT", "BT_AVRC", "BT_A2D",   "BT_GATT",  "BT_SMP",
    "BT_BNEP", "BT_PAN",  "BT_BTC",  "bt",       "BTDM",
};

void writeRawChar(char c) {
    int uartNum = uartGetDebug();
    if (uartNum < 0 || uartNum >= SOC_UART_NUM) {
        return;
    }

    uart_dev_t *hw = UART_LL_GET_HW(uartNum);
    while (uart_ll_get_txfifo_len(hw) == 0) {
        // Match Arduino's UART0 putc behaviour: wait for FIFO space.
    }

    const uint8_t byte = static_cast<uint8_t>(c);
    uart_ll_write_txfifo(hw, &byte, 1);
}

void pushWindow(char c) {
    memmove(gWindow, gWindow + 1, kWindowSize - 1);
    gWindow[kWindowSize - 1] = c;
    gWindow[kWindowSize] = '\0';
}

bool windowEndsWith(const char *suffix) {
    const size_t kSuffixLen = strlen(suffix);
    if (kSuffixLen > kWindowSize) {
        return false;
    }
    return memcmp(gWindow + kWindowSize - kSuffixLen, suffix, kSuffixLen) == 0;
}

size_t markerLength(const char *marker) {
    return strlen(marker);
}

bool isMarkerPrefix(const char *text, size_t len) {
    const char *const kMarkers[] = {kAssertWarnMarker, kAssertErrMarker};
    for (const char *marker : kMarkers) {
        const size_t kMarkerSize = markerLength(marker);
        const size_t kCompareLen = (len < kMarkerSize) ? len : kMarkerSize;
        if (memcmp(text, marker, kCompareLen) == 0) {
            return true;
        }
    }
    return false;
}

bool isCompleteMarker(const char *text, size_t len) {
    const char *const kMarkers[] = {kAssertWarnMarker, kAssertErrMarker};
    for (const char *marker : kMarkers) {
        if (len == markerLength(marker) && memcmp(text, marker, len) == 0) {
            return true;
        }
    }
    return false;
}

void resetSuppressionState() {
    gPendingLen = 0;
    memset(gPending, 0, sizeof(gPending));
    memset(gWindow, 0, sizeof(gWindow));
    gSuppressing = false;
    gSuppressedChars = 0;
}

void processNormalChar(char c);

void flushPending() {
    for (size_t i = 0; i < gPendingLen; ++i) {
        writeRawChar(gPending[i]);
    }
    gPendingLen = 0;
    memset(gPending, 0, sizeof(gPending));
}

void processNormalChar(char c) {
    if (gSuppressing) {
        return;
    }

    if (gPendingLen + 1 <= sizeof(gPending)) {
        gPending[gPendingLen++] = c;
    }

    if (isMarkerPrefix(gPending, gPendingLen)) {
        if (isCompleteMarker(gPending, gPendingLen)) {
            gSuppressing = true;
            gSuppressedChars = 0;
            gPendingLen = 0;
            memset(gPending, 0, sizeof(gPending));
        }
        return;
    }

    // Not the start of an assert marker: emit everything we held back.
    flushPending();
}

void processSuppressedChar(char c) {
    pushWindow(c);
    gSuppressedChars++;

    // Concatenated asserts are common. A fresh marker restarts the safety cap
    // so a continuous burst cannot trip it.
    if (windowEndsWith(kAssertWarnMarker) || windowEndsWith(kAssertErrMarker)) {
        gSuppressedChars = 0;
        return;
    }

    // Controller asserts do not reliably end with a newline. Drop everything
    // through the next newline (or the safety cap) so appended hex output and
    // back-to-back assert fragments cannot leak through.
    if (c == '\n' || c == '\r' || gSuppressedChars > kMaxSuppressedChars) {
        gSuppressing = false;
        gSuppressedChars = 0;
        memset(gWindow, 0, sizeof(gWindow));
        return;
    }
}

void filteredPutc(char c) {
    if (gSuppressing) {
        processSuppressedChar(c);
        return;
    }
    processNormalChar(c);
}

}  // namespace

void wiimoteInstallBluetoothLogFilter() {
    for (const char *tag : kBtLogTags) {
        esp_log_level_set(tag, ESP_LOG_NONE);
    }

    if (gInstalled || uartGetDebug() < 0) {
        return;
    }

    resetSuppressionState();
    ets_install_putc1(&filteredPutc);
    gInstalled = true;
}

#else

void wiimoteInstallBluetoothLogFilter() {}

#endif  // ARDUINO_ARCH_ESP32 || ESP_PLATFORM
