// Copyright (c) 2020 Daiki Yasuda
//
// This is licensed under
// - Creative Commons Attribution-NonCommercial 3.0 Unported
// - https://creativecommons.org/licenses/by-nc/3.0/
// - Or see LICENSE.md

#include "hci_callbacks.h"

#include "../utils/serial_logging.h"
#include "Arduino.h"
#include "TinyWiimote.h"
#include "queue/hci_queue.h"

// Static member initialization
HciQueueManager *HciCallbacksHandler::queueManager = nullptr;

HciCallbacksHandler::HciCallbacksHandler() {
    hciInterface_.hciSendPacket = hciHostSendPacket;
}

void HciCallbacksHandler::setQueueManager(HciQueueManager *queueManager) {
    HciCallbacksHandler::queueManager = queueManager;
}

const struct TwHciInterface *HciCallbacksHandler::getHciInterface() const {
    return &hciInterface_;
}

esp_vhci_host_callback_t *HciCallbacksHandler::getVhciCallback() {
    vhciCallback_.notify_host_recv = notifyHostRecv;
    vhciCallback_.notify_host_send_available = notifyHostSendAvailable;
    return &vhciCallback_;
}

void HciCallbacksHandler::notifyHostSendAvailable() {
    LOG_DEBUG("notifyHostSendAvailable\n");
    if (!tinyWiimoteDeviceIsInited()) {
        tinyWiimoteResetDevice();
    }
}

int HciCallbacksHandler::notifyHostRecv(uint8_t *data, uint16_t len) {
    LOG_DEBUG("notifyHostRecv:");
    for (int i = 0; i < len; i++) {
        LOG_DEBUG(" %02x", data[i]);
    }
    LOG_DEBUG("\n");

    if (queueManager == nullptr) {
        LOG_ERROR("HciCallback: RX queue manager is null\n");
        return ESP_FAIL;
    }

    // A full queue is an intentional drop under overload, not a VHCI error.
    // Returning ESP_FAIL here can make the Bluetooth host retry or stall.
    queueManager->sendToRxQueue(data, len);
    return ESP_OK;
}

void HciCallbacksHandler::hciHostSendPacket(uint8_t *data, size_t len) {
    if (queueManager != nullptr) {
        queueManager->sendToTxQueue(data, len);
    } else {
        LOG_WARN("HciCallback: Queue manager not set, cannot send packet\n");
    }
}
