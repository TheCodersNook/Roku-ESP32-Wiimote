// Copyright (c) 2020 Daiki Yasuda
//
// This is licensed under
// - Creative Commons Attribution-NonCommercial 3.0 Unported
// - https://creativecommons.org/licenses/by-nc/3.0/
// - Or see LICENSE.md

#include "hci_queue.h"

#include "../../utils/serial_logging.h"
#include "Arduino.h"
#include "TinyWiimote.h"
#include "esp_bt.h"

#include <stdlib.h>
#include <string.h>

namespace {
constexpr UBaseType_t kMaxPacketsPerTaskCall = 32;
}  // namespace

HciQueueManager::HciQueueManager(size_t rxQueueSize, size_t txQueueSize)
    : txQueue_(nullptr), rxQueue_(nullptr), rxQueueSize_(rxQueueSize), txQueueSize_(txQueueSize) {}

bool HciQueueManager::createQueues() {
    LOG_DEBUG("HciQueue: Creating TX and RX queues...\n");
    txQueue_ = xQueueCreate(txQueueSize_, sizeof(struct HciQueueData *));
    if (txQueue_ == nullptr) {
        LOG_ERROR("HciQueue: xQueueCreate(txQueue) failed\n");
        return false;
    }

    rxQueue_ = xQueueCreate(rxQueueSize_, sizeof(struct HciQueueData *));
    if (rxQueue_ == nullptr) {
        LOG_ERROR("HciQueue: xQueueCreate(rxQueue) failed\n");
        return false;
    }

    LOG_DEBUG("HciQueue: Queues created successfully\n");
    return true;
}

bool HciQueueManager::sendToQueue(xQueueHandle queue,
                                  uint8_t *data,
                                  size_t len,
                                  const char *debugLabel) {
    LOG_DEBUG("%s\n", debugLabel);

    if ((data == nullptr) || (len == 0U)) {
        LOG_DEBUG("HciQueue: No data to send (len=%d)\n", len);
        return true;
    }

    HciQueueData *queuedata = (HciQueueData *)malloc(sizeof(HciQueueData) + len);
    if (queuedata == nullptr) {
        LOG_ERROR("HciQueue: malloc failed for %d bytes\n", sizeof(HciQueueData) + len);
        return false;
    }

    queuedata->len = len;
    memcpy(queuedata->data, data, len);

    const void *queueItem = reinterpret_cast<const void *>(&queuedata);
    // Never block the VHCI callback. A clone can stream reports faster than the
    // Arduino loop consumes them; blocking here with portMAX_DELAY deadlocks the
    // Bluetooth host task once the queue fills.
    if (xQueueSend(queue, queueItem, 0) != pdPASS) {
        LOG_DEBUG("HciQueue: queue full, dropping packet\n");
        free(queuedata);
        return false;
    }

    return true;
}

bool HciQueueManager::sendToTxQueue(uint8_t *data, size_t len) {
    if (txQueue_ == nullptr) {
        LOG_WARN("HciQueue: TX queue is not initialized\n");
        return false;
    }

    bool result = sendToQueue(txQueue_, data, len, "sendToTxQueue");
    if (result && (data != nullptr) && (len != 0U)) {
        LOG_DEBUG("RECV <= %s\n", format2Hex(data, len));
    }
    return result;
}

bool HciQueueManager::sendToRxQueue(uint8_t *data, size_t len) {
    if (rxQueue_ == nullptr) {
        LOG_WARN("HciQueue: RX queue is not initialized\n");
        return false;
    }

    bool result = sendToQueue(rxQueue_, data, len, "sendToRxQueue");
    if (result && (data != nullptr) && (len != 0U)) {
        LOG_DEBUG("SEND => %s\n", format2Hex(data, len));
    }
    return result;
}

void HciQueueManager::processTxQueue() {
    if (txQueue_ == nullptr) {
        return;
    }

    for (UBaseType_t i = 0; i < kMaxPacketsPerTaskCall && uxQueueMessagesWaiting(txQueue_) != 0U;
         ++i) {
        if (!esp_vhci_host_check_send_available()) {
            break;
        }

        HciQueueData *queuedata = nullptr;
        if (xQueueReceive(txQueue_, reinterpret_cast<void *>(&queuedata), 0) == pdTRUE) {
            esp_vhci_host_send_packet(queuedata->data, queuedata->len);
            LOG_DEBUG("SEND => %s\n", format2Hex(queuedata->data, queuedata->len));
            free(queuedata);
        }
    }
}

void HciQueueManager::processRxQueue() {
    if (rxQueue_ == nullptr) {
        return;
    }

    // Drain in batches so a streaming clone cannot outrun the loop and fill the
    // queue (which would block the VHCI callback).
    for (UBaseType_t i = 0; i < kMaxPacketsPerTaskCall && uxQueueMessagesWaiting(rxQueue_) != 0U;
         ++i) {
        HciQueueData *queuedata = nullptr;
        if (xQueueReceive(rxQueue_, reinterpret_cast<void *>(&queuedata), 0) == pdTRUE) {
            handleHciData(queuedata->data, queuedata->len);
            free(queuedata);
        }
    }
}

bool HciQueueManager::hasTxPending() const {
    return txQueue_ != nullptr && uxQueueMessagesWaiting(txQueue_) > 0U;
}

bool HciQueueManager::hasRxPending() const {
    return rxQueue_ != nullptr && uxQueueMessagesWaiting(rxQueue_) > 0U;
}
